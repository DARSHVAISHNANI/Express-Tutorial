const express = require('express');
const app = express();

app.use(express.static("public"));

app.get('/home', (req, res) => {
    res.sendFile(__dirname + '/views/home.html');
});

app.get('/About', (req, res) => {
    res.sendFile(__dirname + '/views/About.html');
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
